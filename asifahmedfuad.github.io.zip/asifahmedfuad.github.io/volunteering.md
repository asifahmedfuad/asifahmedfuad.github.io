---
layout: default
---
[Home](./)|[Education](./education.html) || [Work](./experience.html) || [Research](./projects.html) || [Publications](./publications.html)|| [Volunteering](./volunteering.html)

# Volunteering

<a href="https://ieeeaiubsb.com">
  <img src="/assets/img/ieee_aiub.png" alt="IEEE and IEEE AIUB SB">
</a>

> Volunteer of IEEE AIUB Student Branch from September 2011 to August 2012

> Webmaster & Designer of IEEE AIUB Student Branch from August 2012 to December 2013 

> Advisor, IEEE Industry Applications Society (IAS) from September 2015.

> Motivator, IEEE AIUB Student Branch since May, 2016.
Responsible to collaborate with student members to organize different events

> Publicity Coordinator (2016), IEEE Bangladesh Section.
Responsible for website designing and updating  

> ACES Alumnus & Research Group Coordinator since 2015.
Supervising undergraduate students to participate in national and international competitions 

> Vice-Chair(Technical) (2018), IEEE Young Professionals Bangladesh

> Student Representative, IPCV Advisory Board.

[Home](./)
