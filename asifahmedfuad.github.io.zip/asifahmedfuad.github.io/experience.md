---
layout: default
---

[Home](./)|[Education](./education.html) || [Work](./experience.html) || [Research](./projects.html) || [Publications](./publications.html)|| [Volunteering](./volunteering.html)

# Experience
<center>
<a href="https://www.aiub.edu/">
  <img src="/assets/img/AIUB_whole_logo.png" alt="AIUB">
</a>
<a href="https://home.cern/">
  <img src="/assets/img/cern.jpg" alt="CERN">
</a>
<a href="https://www.labri.fr">
  <img src="/assets/img/LABRI_small.png" alt="LaBRI">
</a>
</center>
```
January 13, 2016 – Present(On Study Leave)

Lecturer, Department of EEE, 
Faculty of Engineering
American International University-Bangladesh (AIUB)
Dhaka, Bangladesh
www.aiub.edu
```
```
February 06, 2020 – July 03, 2020

Master Thesis Intern, 
Laboratoire Bordelais de Recherche en Informatique(LaBRI)
Bordeaux, France
www.labri.fr
```
```
August 27, 2014 - January 12, 2016

Teaching Assistant, Department of EEE, 
Faculty of Engineering
American International University-Bangladesh (AIUB)
Dhaka, Bangladesh
www.aiub.edu
```
```
July 1, 2019 - August 31, 2019

Openlab Summer Student
Openlab, 
European Organisation for Nuclear Research (CERN) 
www.openlab.cern

```
[Home](./)
